create view label as
select `blog`.`zj_set_artitle_label`.`label_id`   AS `label_id`,
       `blog`.`zj_labels`.`label_name`            AS `label_name`,
       `blog`.`zj_set_artitle_label`.`article_id` AS `article_id`,
       `blog`.`zj_articles`.`article_title`       AS `article_title`
from ((`blog`.`zj_labels` join `blog`.`zj_articles`)
         join `blog`.`zj_set_artitle_label`)
where ((`blog`.`zj_set_artitle_label`.`article_id` = `blog`.`zj_articles`.`article_id`) and
       (`blog`.`zj_set_artitle_label`.`label_id` = `blog`.`zj_labels`.`label_id`));

