create view forums as
select `blog`.`zj_forums`.`forum_id`   AS `forum_id`,
       `blog`.`zj_forums`.`forum_name` AS `forum_name`,
       `blog`.`zj_posts`.`post_id`     AS `post_id`,
       `blog`.`zj_posts`.`post_title`  AS `post_title`
from (`blog`.`zj_forums`
         join `blog`.`zj_posts`)
where (`blog`.`zj_forums`.`forum_id` = `blog`.`zj_posts`.`forum_id`);

