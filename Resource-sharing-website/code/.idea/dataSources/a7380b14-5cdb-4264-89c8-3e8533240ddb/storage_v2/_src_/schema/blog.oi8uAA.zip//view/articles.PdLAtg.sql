create view articles as
select `blog`.`zj_articles`.`user_id`         AS `user_id`,
       `blog`.`zj_users`.`user_name`          AS `user_name`,
       `blog`.`zj_articles`.`article_id`      AS `article_id`,
       `blog`.`zj_articles`.`article_title`   AS `article_title`,
       `blog`.`zj_articles`.`article_content` AS `article_content`
from (`blog`.`zj_articles`
         join `blog`.`zj_users`)
where (`blog`.`zj_articles`.`user_id` = `blog`.`zj_users`.`user_id`);

