create view posts as
select `blog`.`zj_posts`.`user_id`      AS `user_id`,
       `blog`.`zj_users`.`user_name`    AS `user_name`,
       `blog`.`zj_posts`.`post_id`      AS `post_id`,
       `blog`.`zj_posts`.`post_title`   AS `post_title`,
       `blog`.`zj_posts`.`post_content` AS `post_content`,
       `blog`.`zj_posts`.`forum_id`     AS `forum_id`,
       `blog`.`zj_forums`.`forum_name`  AS `forum_name`
from ((`blog`.`zj_posts` join `blog`.`zj_users`)
         join `blog`.`zj_forums`)
where ((`blog`.`zj_posts`.`user_id` = `blog`.`zj_users`.`user_id`) and
       (`blog`.`zj_posts`.`forum_id` = `blog`.`zj_forums`.`forum_id`));

