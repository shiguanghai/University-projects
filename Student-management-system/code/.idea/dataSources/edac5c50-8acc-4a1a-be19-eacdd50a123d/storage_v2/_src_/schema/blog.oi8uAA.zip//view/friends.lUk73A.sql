create view friends as
select `blog`.`zj_user_friends`.`user_id`         AS `user_id`,
       `blog`.`zj_users`.`user_name`              AS `user_name`,
       `blog`.`zj_user_friends`.`user_friends_id` AS `user_friends_id`,
       `blog`.`zj_user_friends`.`user_note`       AS `user_note`
from (`blog`.`zj_users`
         join `blog`.`zj_user_friends`)
where (`blog`.`zj_users`.`user_id` = `blog`.`zj_user_friends`.`user_id`);

