create view sort as
select `blog`.`zj_set_artitle_sort`.`sort_id`    AS `sort_id`,
       `blog`.`zj_sorts`.`sort_name`             AS `sort_name`,
       `blog`.`zj_set_artitle_sort`.`article_id` AS `article_id`,
       `blog`.`zj_articles`.`article_title`      AS `article_title`
from ((`blog`.`zj_articles` join `blog`.`zj_set_artitle_sort`)
         join `blog`.`zj_sorts`)
where ((`blog`.`zj_articles`.`article_id` = `blog`.`zj_set_artitle_sort`.`article_id`) and
       (`blog`.`zj_sorts`.`sort_id` = `blog`.`zj_set_artitle_sort`.`sort_id`));

